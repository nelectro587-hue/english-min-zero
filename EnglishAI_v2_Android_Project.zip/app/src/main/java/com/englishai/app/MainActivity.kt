package com.englishai.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var progressValue = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val status = findViewById<TextView>(R.id.status)
        fun complete(message: String) {
            progressValue = (progressValue + 10).coerceAtMost(100)
            status.text = "مستواك: مبتدئ • التقدم: $progressValue%"
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.lesson).setOnClickListener {
            complete("Lesson 1: Greetings — Hello, Good morning, How are you?")
        }
        findViewById<Button>(R.id.ai).setOnClickListener {
            Toast.makeText(this, "واجهة محادثة AI جاهزة للربط بخادم آمن.", Toast.LENGTH_LONG).show()
        }
        findViewById<Button>(R.id.quiz).setOnClickListener {
            complete("Quiz: اختر الإجابة الصحيحة — I ___ happy. (am / is)")
        }
        findViewById<Button>(R.id.vocab).setOnClickListener {
            complete("كلمات اليوم: learn = يتعلم • speak = يتحدث • improve = يحسن")
        }
        findViewById<Button>(R.id.progress).setOnClickListener {
            Toast.makeText(this, "تقدمك الحالي: $progressValue%", Toast.LENGTH_SHORT).show()
        }
    }
}
